const mongoose = require("mongoose");

const mongoDb = "mongodb+srv://root:root@cluster0.bfoky.mongodb.net/upgrade-rock?retryWrites=true&w=majority";
const GroupSchema = require("../api/group/group.model");
const group= [
{    "name": "Blackmore's Night ",
     "year": " 1997",
     "genre":  [ ],
     "albums":  [ ],
     "members":  [ ],
     "oldMembers":  [ ],
 },
    {
    "name": "Blind Guardian",   
     "year": " 1984",
     "genre":  [ ],
     "albums":  [ ],
     "members":  [ ],
     "oldMembers":  [ ],
 },
    {
    "name": " Deep Purple",   
     "year": " 1968",
     "genre":  [ ],
     "albums":  [ ],
     "members":  [ ],
     "oldMembers":  [ ],
 },
    {
    "name": " Dream Theater",   
     "year": " 1985",
     "genre":  [ ],
     "albums":  [ ],
     "members":  [ ],
     "oldMembers":  [ ],
 },
  {
    "name": " Eagles of Death Metal",   
     "year": " 1998",
     "genre":  [ ],
     "albums":  [ ],
     "members":  [ ],
     "oldMembers":  [ ],
 },
  {
    "name": " Metallica",   
     "year": " 1981",
     "genre":  [ ],
     "albums":  [ ],
     "members":  [ ],
     "oldMembers":  [ ],
 },
  {
    "name": " Rainbow",   
     "year": " 1975",
     "genre":  [ ],
     "albums":  [ ],
     "members":  [ ],
     "oldMembers":  [ ],
 },
  {
    "name": " Rage Against the Machine",   
     "year": "1991",
     "genre":  [ ],
     "albums":  [ ],
     "members":  [ ],
     "oldMembers":  [ ],
 },
  {
    "name": " Twisted Sister",   
     "year": " 1973",
     "genre":  [ ],
     "albums":  [ ],
     "members":  [ ],
     "oldMembers":  [ ],
 },
  {
    "name": " Volbeat",   
     "year": " 2001",
     "genre":  [ ],
     "albums":  [ ],
     "members":  [ ],
     "oldMembers":  [ ],
 },
  {
    "name": "  Mayhem",   
     "year": " 1984",
     "genre":  [ ],
     "albums":  [ ],
     "members":  [ ],
     "oldMembers":  [ ],
 },
  {
    "name": " Behemoth",   
     "year": " 1991",
     "genre":  [ ],
     "albums":  [ ],
     "members":  [ ],
     "oldMembers":  [ ],
 },
];
const groupDocuments = group.map((group) => new GroupSchema(group));

mongoose
  .connect(mongoDb, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(async () => {
    const allGroup = await GroupSchema.find();
    if (allGroup.length) {
      await GroupSchema.collection.drop();
    }
  })
  .catch((err) => console.log(`Error deleting Groups: ${err}`))
  .then(async () => {
    await GroupSchema.insertMany(groupDocuments);
    console.log("Groups successfully created");
  })
  .catch((err) => console.log(`Error creating Groups: ${err}`))
  .finally(() => mongoose.disconnect());