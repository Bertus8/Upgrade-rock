const mongoose = require("mongoose");

const mongoDb = "mongodb+srv://root:root@cluster0.bfoky.mongodb.net/upgrade-rock?retryWrites=true&w=majority";
const MemberSchema = require("../api/member/member.model");
const member= [
{
    "name": " Richard Hugh",
     "surname": "Blackmore",
     "birthDate": " 1965", 
      "role": [" Guitarist", "percusionist", "cellist", "pianist", "bass player" ]
   },
   {
    "name": " Candice Lauren",
     "surname": "Night",
     "birthDate": " 1971", 
      "role": [" Vocals", "shawm", "rauschpfeife", "pennywhistle", "hurdy-gurdy", "recorder",     "cornamuse", "gemshorn"]
   },
   {
    "name": " Hans Jürgen",
     "surname": "Kürsch",
     "birthDate": " 1966", 
      "role": [" Singer", "songwriter"]
   },
   {
    "name": " André",
     "surname": "Olbrich",
     "birthDate": " 1967", 
      "role": ["Guitarist"]
   },
   {
    "name": " Marcus",
     "surname": "Siepen",
     "birthDate": " 1968", 
      "role": ["Guitarist"]
   },
   {
    "name": " Frederik ",
     "surname": "Ehmke",
     "birthDate": " 1978", 
      "role": ["drums", "percussion", "flute", "bagpipes"]
   },
   {
    "name": "Johan",
     "surname": "van Stratum",
     "birthDate": " 1982", 
      "role": ["Bass","guitar"]
   },
   {
    "name": "JohanIan Anderson",
     "surname": "Paice",
     "birthDate": " 1948", 
      "role": ["drums",]
   },
   {
    "name": "Ian",
     "surname": "Gillan",
     "birthDate": " 1945", 
      "role": [" Singer","drums",]
   },
   {
    "name": "Roger David",
     "surname": "Glover",
     "birthDate": " 1945", 
      "role": [" Singer"," Guitarist", "percusionist", "pianist", "bass player" ]
   },
   {
    "name": "Steve J.",
     "surname": "Morse ",
     "birthDate": " 1954", 
      "role": [" Guitarist"]
   },
   {
    "name": "Donald Smith",
     "surname": "Airey ",
     "birthDate": " 1948", 
      "role": ["pianist"]
   },
   {
    "name": "James ",
     "surname": "LaBrie  ",
     "birthDate": " 1963", 
      "role": [" Singer"]
   },
   {
    "name": "John ",
     "surname": "Petrucci ",
     "birthDate": "1967", 
      "role": [" Singer"," Guitarist"]
   },
   {
    "name": "John ",
     "surname": "Myung ",
     "birthDate": "1967", 
      "role": ["bass player" ]
   },
   {
    "name": "Jordan ",
     "surname": "Rudess",
     "birthDate": "1956", 
      "role": ["pianist"," Singer" ]
   },   
   {
    "name": "Jesse",
     "surname": "Hughes",
     "birthDate": "1972", 
      "role": ["drums" ]
   },
   {
    "name": "Josh ",
     "surname": "Homme",
     "birthDate": "1973", 
      "role": ["drums" ]
   },
   {
    "name": "Steve ",
     "surname": "Harris",
     "birthDate": "1956", 
      "role": [" Singer","pianist", "bass player" ]
   },
   {
    "name": "Dave ",
     "surname": "Murray",
     "birthDate": "1956", 
      "role": [" Guitarist" ]
   },
   {
    "name": "Adrian ",
     "surname": "Smith",
     "birthDate": "1957", 
      "role": [" Guitarist" ]
   },
   {
    "name": "Bruce ",
     "surname": "Dickinson",
     "birthDate": "1958", 
      "role": ["Singer" ]
   },
   {
    "name": "Nicko ",
     "surname": "McBrain",
     "birthDate": "1952", 
      "role": ["Drums" ]
   },
   {
    "name": "Janick ",
     "surname": "Gers",
     "birthDate": "1957", 
      "role": [" Guitarist"]
   },   
   {
    "name": "James ",
     "surname": "Hetfield",
     "birthDate": "1963", 
      "role": ["Singer", " Guitarist"]
   },
   {
    "name": "Lars",
     "surname": "Ulrich",
     "birthDate": "1963", 
      "role": ["Drums" ]
   },
   {
    "name": "Kirk",
     "surname": "Hammett",
     "birthDate": "1962", 
      "role": [" Guitarist" ]
   },
   {
    "name": "Robert",
     "surname": "Trujillo",
     "birthDate": "1964", 
      "role": ["bass player"  ]
   },   
   {
    "name": "Ronnie",
     "surname": "Romero",
     "birthDate": "1981", 
      "role": ["Singer"  ]
   },
   {
    "name": "Jens",
     "surname": "Johansson",
     "birthDate": "1963", 
      "role": ["Keyboards"  ]
   },
   {
    "name": "Bob",
     "surname": "Curiano",
     "birthDate": "1952", 
      "role": ["bass player" ]
   },
   {
    "name": "David",
     "surname": "Keith",
     "birthDate": "1973", 
      "role": ["Drums"  ]
   },  
   {
    "name": "Tim",
     "surname": "Commerford",
     "birthDate": "1968", 
      "role": ["bass player"  ]
   },
   {
    "name": "Zack",
     "surname": "De la Rocha",
     "birthDate": "1972", 
      "role": [" Singer","pianist", "Drums" , " Guitarist"  ]
   },
   {
    "name": "Tom",
     "surname": "Morello",
     "birthDate": "1973", 
      "role": [" Singer", " Guitarist"  ]
   },
   {
    "name": "Brad",
     "surname": "Wilk",
     "birthDate": "1968", 
      "role": ["Drums"," Singer" ]
   },   
   {
    "name": "Jay Jay",
     "surname": "French",
     "birthDate": "1952", 
      "role": ["guitars","vocals" ]
   },
   {
    "name": "Eddie",
     "surname": "Ojeda",
     "birthDate": "1955", 
      "role": ["guitars","vocals" ]
   },
   {
    "name": "Dee",
     "surname": "Snider",
     "birthDate": "1955", 
      "role": ["guitars","vocals" ]
   },
   {
    "name": "Mark",
     "surname": "Mendoza",
     "birthDate": "1955", 
      "role": ["bass player","vocals" ]
   },   
   {
    "name": "A.J",
     "surname": "Pero",
     "birthDate": "1959", 
      "role": ["Drums","vocals" ]
   },
   {
    "name": "Michael",
     "surname": "Poulsen",
     "birthDate": "1975", 
      "role": ["guitars","vocals"  ]
   },
   {
    "name": "Jon",
     "surname": "Larsen",
     "birthDate": "1970", 
      "role": ["Drums"]
   },
   {
    "name": "Rob",
     "surname": "Caggiano",
     "birthDate": "1976", 
      "role": ["guitars" ]
   },
   {
    "name": "Kaspar",
     "surname": "Boye Larsen",
     "birthDate": "1975", 
      "role": ["guitars"  ]
   },
   {
    "name": "Necrobutcher",
     "surname": "",
     "birthDate": "1975", 
      "role": ["guitars","vocals","bass player" ]
   },
   {
    "name": "Hellhammer",
     "surname": "",
     "birthDate": "1969", 
      "role": ["Drums"  ]
   },
   {
    "name": "Attila",
     "surname": "Csihar",
     "birthDate": "1971", 
      "role": [" Singer"  ]
   },   
   {
    "name": "Teloch",
     "surname": "",
     "birthDate": "1974", 
      "role": ["guitars","vocals","bass player" ]
   },
   {
    "name": "Ghul",
     "surname": "",
     "birthDate": "1981", 
      "role": [" Singer"," Guitarist", "percusionist", "pianist", "bass player" ]
   },
   {
    "name": "Nergal",
     "surname": "",
     "birthDate": "1981", 
      "role": ["guitars","vocals"]
   },
   {
    "name": "Inferno",
     "surname": "",
     "birthDate": "1978", 
      "role": [" Drums" ]
   },
   {
    "name": "Orion",
     "surname": "",
     "birthDate": "1980", 
      "role": [" Singer"," Guitarist","bass player" ]
   },
   {
    "name": "Seth",
     "surname": "",
     "birthDate": "1979", 
      "role": [" Singer"," Guitarist" ]
   },
];
const memberDocuments = member.map((member) => new MemberSchema(member));

mongoose
  .connect(mongoDb, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(async () => {
    const allMember = await MemberSchema.find();
    if (allMember.length) {
      await MemberSchema.collection.drop();
    }
  })
  .catch((err) => console.log(`Error deleting Members: ${err}`))
  .then(async () => {
    await MemberSchema.insertMany(memberDocuments);
    console.log("Member successfully created");
  })
  .catch((err) => console.log(`Error creating Members: ${err}`))
  .finally(() => mongoose.disconnect());