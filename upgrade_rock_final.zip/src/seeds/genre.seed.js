const mongoose = require("mongoose");

const mongoDb = "mongodb+srv://root:root@cluster0.bfoky.mongodb.net/upgrade-rock?retryWrites=true&w=majority";
const GenreSchema = require("../api/genre/genre.model");
const genre= [
{
    "name": " Folk Rock",
    "description": " Es un género musical que combina elementos de la música folk, el blues y el rock.",
     "location": " US y UK " ,
      "decade": " 60" 
    },
    {
    "name": " Power metal",
    "description": " is a subgenre of heavy metal combining characteristics of traditional heavy metal with speed metal, often within symphonic context. Generally, power metal is characterized by a faster, lighter, and more uplifting sound,",
     "location": " Europe " ,
      "decade": " 80" 
    },
    {
    "name": " Symphonic metal",
    "description": " is a cross-generic style designation for the symphonic subsets of heavy metal music subgenres. It is used to denote any metal band that makes use of symphonic or orchestral elements.",
     "location": " Europe " ,
      "decade": " 90" 
    },
    {
    "name": " hard rock",
    "description": " is a loosely defined subgenre of rock music typified by a heavy use of aggressive vocals, distorted electric guitars, bass guitar, and drums, sometimes accompanied with keyboards.",
     "location": " Europe, US" ,
      "decade": " 60" 
    },
    {
    "name": " Heavy metal ",
    "description": " is a genre of rock music that developed in the late 1960s and early 1970s, largely in the United Kingdom and United States. With roots in blues rock, psychedelic rock and acid rock, heavy metal bands developed a thick, monumental sound characterized by distortion, extended guitar solos, emphatic beats and loudness." ,
      "location": " Europe, US" ,
      "decade": " 60" 
    },
    {
    "name": " Progressive metal ",
    "description": " is a broad fusion music genre melding heavy metal and progressive rock, combining the loud aggression and amplified guitar-driven sound of the former with the more experimental, cerebral or pseudo-classical compositions of the latter." ,
      "location": " Europe" ,
      "decade": " 80" 
    },
    {
    "name": " Rockabilly",
    "description": "is one of the earliest styles of rock and roll music. It dates back to the early 1950s in the United States, especially the South. As a genre it blends the sound of Western musical styles such as country with that of rhythm and blues,[1][2] leading to what is considered classic rock and roll." ,
      "location": "US" ,
      "decade": " 50" 
    },
    {
    "name": " Garage rock",
    "description": "is a raw and energetic style of rock and roll that flourished in the mid-1960s, most notably in the United States and Canada, and has experienced a series of subsequent revivals. The style is characterized by basic chord structures played on electric guitars and other instruments, sometimes distorted through a fuzzbox, as well as often unsophisticated and occasionally aggressive lyrics and delivery. " ,
      "location": "US" ,
      "decade": " 60" 
    },
    {
    "name": "Thrash metal",
    "description": "is an extreme subgenre of heavy metal music characterized by its overall aggression and often fast tempo.[4] The songs usually use fast percussive beats and low-register guitar riffs, overlaid with shredding-style lead guitar work." ,
      "location": "US, UK, GB" ,
      "decade": " 80" 
    },
    {
    "name": "Alternative metal",
    "description": "is a genre of heavy metal music that combines heavy metal with influences from alternative rock and other genres not normally associated with metal. Alternative metal bands are often characterized by heavily downtuned, mid-paced guitar riffs, a mixture of accessible melodic vocals and harsh vocals and sometimes unconventional sounds within other heavy metal styles." ,
      "location": "US" ,
      "decade": " 80" 
    },
    {
    "name": "Glam metal",
    "description": "is a subgenre of heavy metal that features pop-influenced hooks and guitar riffs, upbeat rock anthems, and slow power ballads. It borrows heavily from the fashion and image of 1970s glam rock." ,
      "location": "US" ,
      "decade": " 70" 
    },
    {
    "name": "Groove metal",
    "description": "is a subgenre of heavy metal music that began in the early 1990s. The genre achieved mainstream success in the 1990s and continued having some more success in the 2000s. Inspired by thrash metal and traditional heavy metal, groove metal features raspy singing and screaming, down-tuned guitars, heavy guitar riffs, and syncopated rhythms." ,
      "location": "US" ,
      "decade": " 90" 
    },
    {
    "name": "Black metal",
    "description": "is an extreme subgenre of heavy metal music. Common traits include fast tempos, a shrieking vocal style,[13][14][15] heavily distorted guitars played with tremolo picking, raw (lo-fi) recording, unconventional song structures, and an emphasis on atmosphere. Artists often appear in corpse paint and adopt pseudonyms.",
      "location": "EU" ,
      "decade": " 80" 
    },
    {
    "name": "Blackened death metal",
    "description": "is an extreme subgenre of heavy metal that fuses elements of black metal and death metal.The genre emerged in early 1990s when black metal bands began incorporating elements of death metal and vice versa. ",
      "location": "Central Europe" ,
      "decade": " 90" 
    },
  ];
  const genreDocuments = genre.map((genre) => new GenreSchema(genre));
  
  mongoose
    .connect(mongoDb, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    })
    .then(async () => {
      const allGenre = await GenreSchema.find();
      if (allGenre.length) {
        await GenreSchema.collection.drop();
      }
    })
    .catch((err) => console.log(`Error deleting Genres: ${err}`))
    .then(async () => {
      await GenreSchema.insertMany(genreDocuments);
      console.log("Genre successfully created");
    })
    .catch((err) => console.log(`Error creating genres: ${err}`))
    .finally(() => mongoose.disconnect());